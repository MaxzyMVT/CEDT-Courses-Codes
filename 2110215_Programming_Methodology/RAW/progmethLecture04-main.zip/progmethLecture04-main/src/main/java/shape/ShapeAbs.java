package shape;

public abstract class ShapeAbs implements Shapeable {

	@Override
	public double getArea() {
		// TODO Auto-generated method stub
		return 0;
	}

}


public interface Perform {
	int compute(int a, int b);
}

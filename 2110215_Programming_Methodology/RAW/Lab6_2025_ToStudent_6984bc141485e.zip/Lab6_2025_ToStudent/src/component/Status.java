package component;

public enum Status {
	NONE,
	INCORRECT,
	PARTIAL,
	CORRECT,
}

package function;

public enum Function {
    SIGMOID,
    TANH,
    RELU
}


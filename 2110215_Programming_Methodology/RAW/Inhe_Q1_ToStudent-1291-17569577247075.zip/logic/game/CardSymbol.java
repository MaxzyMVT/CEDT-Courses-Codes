package logic.game;

public enum CardSymbol {
	ONE,
	TWO,
	THREE,
	FOUR,
	DRAW;

}

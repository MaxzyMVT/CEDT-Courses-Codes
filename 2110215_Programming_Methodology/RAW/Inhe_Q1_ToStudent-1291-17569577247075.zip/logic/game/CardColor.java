package logic.game;

public enum CardColor {
	
	RED,
	BLUE,
	GREEN,
	YELLOW;
}

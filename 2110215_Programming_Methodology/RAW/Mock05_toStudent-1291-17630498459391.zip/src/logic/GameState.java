package logic;

public enum GameState {
    STOPPING,
    PLAYING,
    RUNNING
}

package logic;

public enum Tile {
    DEER,
    WALL,
    GROUND,
    SHIKASENBEI,
    EMPTY
}

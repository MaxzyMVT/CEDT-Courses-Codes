package logic;

public enum Command {
    UP,
    DOWN,
    LEFT,
    RIGHT
}

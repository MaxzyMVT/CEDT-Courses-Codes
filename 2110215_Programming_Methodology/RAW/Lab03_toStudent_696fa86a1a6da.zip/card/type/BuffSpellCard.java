package card.type;

import card.base.SpellCard;
import card.base.UnitCard;

//You CAN modify the first line
public class BuffSpellCard extends SpellCard {

	public BuffSpellCard(String name, String flavorText, int bloodCost, 
			boolean isBurstSpeed, int powerIncrease) {
		
	}

}
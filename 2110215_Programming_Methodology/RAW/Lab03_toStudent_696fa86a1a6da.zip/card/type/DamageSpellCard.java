package card.type;

import card.base.SpellCard;
import card.base.UnitCard;

//You CAN modify the first line
public class DamageSpellCard extends SpellCard {
	
	public DamageSpellCard(String name, String flavorText, int bloodCost, 
			boolean isBurstSpeed, int damage) {

	}

}
package Student;

public class StudentTest1 {
	public static void main(String[] args) {
		Student s1 = new UndergraduateStudent("Toey");
		Student s2 = new GraduateStudent("Nat");
		Student s3 = new Student("Jump");

        //s1.printName();
        //s2.printName();
        //s3.printName();

		//Object x = new Object();
		/*if ((s2.getClass() + "").equals("class Student.GraduateStudent")) {
			System.out.println("YES, a wanted class");
		}else {
			System.out.println("NOT a wanted class");
			System.out.println(s2.getClass() + "");
		}*/
		
		/*
        if(s1 instanceof UndergraduateStudent) {
			System.out.println("s1 is Undergrad");
			UndergraduateStudent riderS = (UndergraduateStudent)s1;
			
		}
		
		if(s1 instanceof Student) {
			System.out.println("s1 is Student");
		}*/


		
		


	}
}

package Student;

public class StudentTest3 {
	public static void main(String[] args) {
		// upcasting (automatically)
		Student s1 = new GraduateStudent("Nat");
		//s1.printName();

		Student s2 = new UndergraduateStudent("Boy");

        // downcasting (manually) � may have problem
		Student s = new Student("Luck");
		
		
	    //GraduateStudent s3 = s1;
		
		//s2 = (UndergraduateStudent) s;
		
		//UndergraduateStudent s3 = (UndergraduateStudent)s1;
		
		UndergraduateStudent s4 = (UndergraduateStudent) s2;
		s4.printName();
	}
}

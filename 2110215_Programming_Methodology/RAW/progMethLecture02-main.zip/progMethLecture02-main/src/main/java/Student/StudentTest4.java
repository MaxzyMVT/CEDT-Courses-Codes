package Student;

public class StudentTest4 {
	public static void main(String[] args) {
		Student s;
		GraduateStudent g = new GraduateStudent("Nat");
		UndergraduateStudent u = new UndergraduateStudent("Toey");		
		s = g;
		s.printName();
		s = u;
		s.printName();
	
        //u=s;
		
		g.printA();
		s.printA();
		((UndergraduateStudent)s).computeCourseGrade();
// 095 165 9888
	}
}


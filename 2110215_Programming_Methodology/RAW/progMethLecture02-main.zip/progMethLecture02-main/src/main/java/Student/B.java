package Student;

public class B extends A {
	public void foo() {
		System.out.println("B");
	}

	public static void main(String[] args) {
	   A x = new B();
        //x.foo();
		if (x instanceof A) { // incorrect
			System.out.println("x is A");
		} else if (x instanceof B) {
			System.out.println("x is B");
		}

		Class a = x.getClass();
		System.out.println(a);
		if (a.equals(A.class)) {
			System.out.println("x is A");
		}
		else if (a.equals(B.class)) {
			System.out.println("x is B");
		}
		
		
		
		



	}

}

package PetShop;

public class Dog extends Animal{
	public void speak() {
		System.out.println("Me----Hong");
	}

}

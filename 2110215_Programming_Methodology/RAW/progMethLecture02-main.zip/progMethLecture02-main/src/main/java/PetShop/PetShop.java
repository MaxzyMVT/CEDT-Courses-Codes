package PetShop;

public class PetShop {

	public static void main(String[] args) {
		Animal[] a = new Animal[3];
		Animal a1 = new Animal();
		Cat a2 = new Cat();
		Dog a3 = new Dog();
		
		a[0] = a1;
		a[1] = a2;
		a[2] = a3;
		
		///////
		//................................................................////
		
		
		Animal x = a[1];
		x.speak();
		Cat y = null;
		if (x instanceof Cat) {
			y = (Cat)x;
		}
		
		
		
		y.kuan();
			
		
		
		
		
		
		
		
		
		
	}

}

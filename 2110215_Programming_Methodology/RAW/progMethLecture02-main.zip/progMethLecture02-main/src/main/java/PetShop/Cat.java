package PetShop;

public class Cat extends Animal {


    public void speak() {
		System.out.println("Meaw");
	}
	
	public void kuan() {
		System.out.println("xxxxxXXXXXXXXXXXxXXX");
	}

}

package PetShop;

public class Animal {
    public void speak() {
		System.out.println("Animal");
	}
	

}

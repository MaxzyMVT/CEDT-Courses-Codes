package ABCStatic;

class A{
    static void m1(){
        System.out.println("A.m1()");
    }
}


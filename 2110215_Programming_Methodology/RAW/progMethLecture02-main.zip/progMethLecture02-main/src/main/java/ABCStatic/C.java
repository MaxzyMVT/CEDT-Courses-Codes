package ABCStatic;

public class C {
    public static void main(String[] a){
        B b = new B();
        b.m1();

        A c = new B();
        c.m1();
    }


}

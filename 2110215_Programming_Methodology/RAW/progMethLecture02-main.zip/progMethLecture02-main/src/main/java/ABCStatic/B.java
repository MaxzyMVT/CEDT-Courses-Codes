package ABCStatic;

class B extends A{
    static void m1(){
        System.out.println("B.m1()");
    }
}


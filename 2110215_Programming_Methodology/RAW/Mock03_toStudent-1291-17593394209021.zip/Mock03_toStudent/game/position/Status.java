package game.position;

public enum Status {
    NORMAL,
    BISHOP,
    KNIGHT,
    ROOK,
    QUEEN,
    PROMOTE,
    CHECK,
    WIN,
}

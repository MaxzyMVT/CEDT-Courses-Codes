package logic;

public enum SquareMark {
	ONE,
	NOTHING,
	MINE;
}

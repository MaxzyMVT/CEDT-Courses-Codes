package logic;

public enum SquareState {
	CONCEALED,
	REVEALED,
	SECURED;
}

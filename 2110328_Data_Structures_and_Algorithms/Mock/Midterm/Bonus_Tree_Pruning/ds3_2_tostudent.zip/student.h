#ifndef __STUDENT_H_
#define __STUDENT_H_
#include "map_bst.h"

//this is the modify() function to be submitted
template <typename KeyT,
          typename MappedT,
          typename CompareT >
void CP::map_bst<KeyT,MappedT,CompareT>::modify(
	CP::map_bst<KeyT,MappedT,CompareT> &other
) {
	
	//your code here
	
	return;
}

//you may use this function to traverse and graft
template <typename KeyT,
          typename MappedT,
          typename CompareT >
void CP::map_bst<KeyT,MappedT,CompareT>::graft(
	CP::map_bst<KeyT,MappedT,CompareT>::node* n, CP::map_bst<KeyT,MappedT,CompareT>::node* m, size_t otherSize
) {
	
	//your code here
	
	return;
}

//you may use this function to traverse and prune
template <typename KeyT,
          typename MappedT,
          typename CompareT >
int CP::map_bst<KeyT,MappedT,CompareT>::prune(
	CP::map_bst<KeyT,MappedT,CompareT>::node* n, KeyT upper, KeyT lower, int aux1, int aux2
) {
	
	//your code here
	
	return;
}

#endif

#ifndef __APLUSB_H_
#define __APLUSB_H_

int sum(int A, int B) {
  //you code here
}

#endif
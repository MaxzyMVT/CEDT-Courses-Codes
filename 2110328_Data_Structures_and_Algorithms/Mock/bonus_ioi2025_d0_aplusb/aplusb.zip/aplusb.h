#ifndef __APLUSB_H_
#define __APLUSB_H_
#include <vector>

void initialize(std::vector<int> A, std::vector<int> B) {
  //you code here
  return;
}

int answer_question(int i, int j) {
  // you code here
  return 0;
}

#endif
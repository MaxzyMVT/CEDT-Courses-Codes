#include "priority_queue.h"
#include <utility>

template <typename T,typename Comp>
void CP::priority_queue<T, Comp>::child_swap(size_t k) {
  return ;
}
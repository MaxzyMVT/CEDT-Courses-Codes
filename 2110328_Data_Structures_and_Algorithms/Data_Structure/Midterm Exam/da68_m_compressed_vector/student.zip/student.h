#ifndef __STUDENT_H_
#define __STUDENT_H_

#include "compressed_vector.h"
#include <cstdlib>

template <typename T> void CP::CompressedVector<T>::expand(size_t capacity) {
  // write your code here
}

template <typename T>
void CP::CompressedVector<T>::insert(int index, const T &element) {
  // write your code here
}

template <typename T> T &CP::CompressedVector<T>::operator[](int index) const {
  // write your code here
}

#endif
